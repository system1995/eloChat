exports.Versus=[
    {
        name:'in comparison to'
    },
    {
        name:'compared to'
    },
    {
        name:'vs'
    },
    {
        name:'versus'
    }
]