

export default {
    compareDates : false,
    yesterdayMetric : false
}